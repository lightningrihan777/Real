import { Float } from '@react-three/drei';
import { Lightbulb, Droplets, Trees, GraduationCap } from 'lucide-react';
import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Group } from 'three';

const FloatingIcon = ({ position, color, delay = 0 }: { position: [number, number, number], color: string, delay?: number }) => {
  const groupRef = useRef<Group>(null);
  
  useFrame((state) => {
    if (groupRef.current) {
      const time = state.clock.getElapsedTime() + delay;
      groupRef.current.position.y = position[1] + Math.sin(time) * 0.3;
      groupRef.current.rotation.y = time * 0.5;
    }
  });

  return (
    <group ref={groupRef} position={position}>
      <mesh>
        <boxGeometry args={[0.4, 0.4, 0.1]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} />
      </mesh>
    </group>
  );
};

export const EnvironmentElements = () => {
  return (
    <>
      {/* Ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]} receiveShadow>
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial color="#86efac" />
      </mesh>

      {/* Trees */}
      <Float speed={2} rotationIntensity={0.2} floatIntensity={0.3}>
        <group position={[-4, -1, -2]}>
          <mesh position={[0, 0, 0]}>
            <cylinderGeometry args={[0.2, 0.2, 1.5, 8]} />
            <meshStandardMaterial color="#7c2d12" />
          </mesh>
          <mesh position={[0, 1, 0]}>
            <coneGeometry args={[0.8, 1.5, 8]} />
            <meshStandardMaterial color="#15803d" />
          </mesh>
        </group>
      </Float>

      <Float speed={2.5} rotationIntensity={0.2} floatIntensity={0.3}>
        <group position={[4, -1, -3]}>
          <mesh position={[0, 0, 0]}>
            <cylinderGeometry args={[0.2, 0.2, 1.5, 8]} />
            <meshStandardMaterial color="#7c2d12" />
          </mesh>
          <mesh position={[0, 1, 0]}>
            <coneGeometry args={[0.8, 1.5, 8]} />
            <meshStandardMaterial color="#15803d" />
          </mesh>
        </group>
      </Float>

      {/* Simple house */}
      <Float speed={1.5} rotationIntensity={0.1} floatIntensity={0.2}>
        <group position={[-5, -0.5, -5]}>
          <mesh position={[0, 0, 0]}>
            <boxGeometry args={[1.5, 1, 1.5]} />
            <meshStandardMaterial color="#dc2626" />
          </mesh>
          <mesh position={[0, 0.8, 0]} rotation={[0, Math.PI / 4, 0]}>
            <coneGeometry args={[1.2, 0.6, 4]} />
            <meshStandardMaterial color="#991b1b" />
          </mesh>
        </group>
      </Float>

      {/* Floating development icons */}
      <FloatingIcon position={[-3, 2, -1]} color="#eab308" delay={0} />
      <FloatingIcon position={[3, 2.5, -2]} color="#3b82f6" delay={1} />
      <FloatingIcon position={[-2, 3, 2]} color="#22c55e" delay={2} />
      <FloatingIcon position={[2, 2.8, 1]} color="#f97316" delay={3} />
    </>
  );
};
