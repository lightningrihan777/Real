import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh } from 'three';
import { Text } from '@react-three/drei';
import { useLanguage } from '@/contexts/LanguageContext';

export const CandidateCharacter = () => {
  const bodyRef = useRef<Mesh>(null);
  const headRef = useRef<Mesh>(null);
  const leftArmRef = useRef<Mesh>(null);
  const rightArmRef = useRef<Mesh>(null);
  const { t } = useLanguage();

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    
    // Breathing animation
    if (bodyRef.current) {
      bodyRef.current.scale.y = 1 + Math.sin(time * 2) * 0.02;
    }
    
    // Head slight rotation
    if (headRef.current) {
      headRef.current.rotation.y = Math.sin(time * 0.5) * 0.1;
    }
    
    // Arms waving
    if (leftArmRef.current) {
      leftArmRef.current.rotation.z = Math.sin(time * 2) * 0.3 + 0.3;
    }
    if (rightArmRef.current) {
      rightArmRef.current.rotation.z = Math.sin(time * 2 + Math.PI) * 0.3 - 0.3;
    }
  });

  return (
    <group position={[0, 0, 0]}>
      {/* Body */}
      <mesh ref={bodyRef} position={[0, 0, 0]} castShadow>
        <cylinderGeometry args={[0.5, 0.6, 1.5, 32]} />
        <meshStandardMaterial color="#2563eb" />
      </mesh>

      {/* Head */}
      <mesh ref={headRef} position={[0, 1.2, 0]} castShadow>
        <sphereGeometry args={[0.4, 32, 32]} />
        <meshStandardMaterial color="#f0c674" />
      </mesh>

      {/* Eyes */}
      <mesh position={[-0.15, 1.3, 0.35]}>
        <sphereGeometry args={[0.05, 16, 16]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
      <mesh position={[0.15, 1.3, 0.35]}>
        <sphereGeometry args={[0.05, 16, 16]} />
        <meshStandardMaterial color="#000000" />
      </mesh>

      {/* Smile */}
      <mesh position={[0, 1.1, 0.38]} rotation={[0, 0, 0]}>
        <torusGeometry args={[0.15, 0.02, 16, 32, Math.PI]} />
        <meshStandardMaterial color="#000000" />
      </mesh>

      {/* Left Arm */}
      <mesh ref={leftArmRef} position={[-0.6, 0.3, 0]} rotation={[0, 0, 0.3]} castShadow>
        <cylinderGeometry args={[0.1, 0.1, 0.8, 16]} />
        <meshStandardMaterial color="#2563eb" />
      </mesh>

      {/* Right Arm */}
      <mesh ref={rightArmRef} position={[0.6, 0.3, 0]} rotation={[0, 0, -0.3]} castShadow>
        <cylinderGeometry args={[0.1, 0.1, 0.8, 16]} />
        <meshStandardMaterial color="#2563eb" />
      </mesh>

      {/* Legs */}
      <mesh position={[-0.2, -1, 0]} castShadow>
        <cylinderGeometry args={[0.15, 0.12, 1, 16]} />
        <meshStandardMaterial color="#1e40af" />
      </mesh>
      <mesh position={[0.2, -1, 0]} castShadow>
        <cylinderGeometry args={[0.15, 0.12, 1, 16]} />
        <meshStandardMaterial color="#1e40af" />
      </mesh>

      {/* Nameplate */}
      <Text
        position={[0, -2, 0]}
        fontSize={0.3}
        color="#16a34a"
        anchorX="center"
        anchorY="middle"
        font="/fonts/inter-bold.woff"
      >
        {t('Your Lovable Candidate', 'നിങ്ങളുടെ സ്നേഹനീയ സ്ഥാനാർത്ഥി')}
      </Text>
    </group>
  );
};
