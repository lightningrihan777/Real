import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { CheckCircle, XCircle } from 'lucide-react';

export const VoteButtons = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();

  return (
    <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-40 flex gap-6 flex-wrap justify-center px-4">
      <Button
        onClick={() => navigate('/vote-udf')}
        size="lg"
        className="bg-success hover:bg-success/90 text-success-foreground shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 text-lg px-8 py-6 animate-glow"
      >
        <CheckCircle className="mr-2 h-6 w-6" />
        {t('Will you vote for UDF?', 'UDF-ന് വോട്ട് ചെയ്യുമോ?')}
      </Button>

      <Button
        onClick={() => navigate('/vote-other')}
        size="lg"
        variant="destructive"
        className="shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 text-lg px-8 py-6"
      >
        <XCircle className="mr-2 h-6 w-6" />
        {t('Vote for Another Party', 'മറ്റൊരു പാർട്ടിക്ക് വോട്ട് ചെയ്യുക')}
      </Button>
    </div>
  );
};
