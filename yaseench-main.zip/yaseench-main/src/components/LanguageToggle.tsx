import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Languages } from 'lucide-react';

export const LanguageToggle = () => {
  const { language, toggleLanguage } = useLanguage();

  return (
    <Button
      onClick={toggleLanguage}
      variant="outline"
      size="lg"
      className="fixed top-6 right-6 z-50 bg-card/80 backdrop-blur-sm border-2 border-primary/30 hover:border-primary hover:shadow-lg transition-all duration-300"
    >
      <Languages className="mr-2 h-5 w-5" />
      {language === 'en' ? 'മലയാളം' : 'English'}
    </Button>
  );
};
