import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { ArrowLeft, Frown } from 'lucide-react';
import { useEffect, useState } from 'react';

const VoteOther = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    setTimeout(() => setShowContent(true), 300);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-muted via-background to-muted relative overflow-hidden">
      {/* Sad floating emoji */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 text-9xl animate-float opacity-20">
        😔
      </div>

      <div className="container mx-auto px-4 py-12 relative z-10">
        <Button
          onClick={() => navigate('/')}
          variant="outline"
          size="lg"
          className="mb-8 animate-fade-in"
        >
          <ArrowLeft className="mr-2 h-5 w-5" />
          {t('Back to Home', 'ഹോമിലേക്ക് മടങ്ങുക')}
        </Button>

        <div className={`text-center max-w-3xl mx-auto transition-all duration-1000 ${showContent ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="mb-8 animate-fade-in">
            <Frown className="h-32 w-32 text-muted-foreground mx-auto mb-6" />
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-foreground mb-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            {t('We Understand', 'ഞങ്ങൾ മനസ്സിലാക്കുന്നു')}
          </h1>

          <div className="bg-card p-8 rounded-2xl shadow-xl mb-8 animate-fade-in" style={{ animationDelay: '0.4s' }}>
            <p className="text-2xl text-card-foreground mb-6">
              {t(
                "Okay... no problem 😔",
                "ശരി... കുഴപ്പമില്ല 😔"
              )}
            </p>
            <p className="text-xl text-muted-foreground mb-6">
              {t(
                'We respect your choice.',
                'നിങ്ങളുടെ തിരഞ്ഞെടുപ്പിനെ ഞങ്ങൾ ബഹുമാനിക്കുന്നു.'
              )}
            </p>
            <p className="text-lg text-muted-foreground">
              {t(
                'We hope you will support us next time. Our doors are always open for everyone in our community.',
                'അടുത്ത തവണ നിങ്ങൾ ഞങ്ങളെ പിന്തുണയ്ക്കുമെന്ന് ഞങ്ങൾ പ്രതീക്ഷിക്കുന്നു. ഞങ്ങളുടെ സമൂഹത്തിലെ എല്ലാവർക്കും ഞങ്ങളുടെ വാതിലുകൾ എല്ലായ്പ്പോഴും തുറന്നിരിക്കുന്നു.'
              )}
            </p>
          </div>

          <div className="bg-gradient-to-r from-primary/20 to-accent/20 p-6 rounded-xl animate-fade-in" style={{ animationDelay: '0.6s' }}>
            <p className="text-lg text-foreground mb-4">
              {t(
                'Democracy is about choices. We will continue to serve our ward with dedication, regardless of your vote. Thank you for considering us.',
                'ജനാധിപത്യം തിരഞ്ഞെടുപ്പുകളെക്കുറിച്ചാണ്. നിങ്ങളുടെ വോട്ട് പരിഗണിക്കാതെ തന്നെ ഞങ്ങളുടെ വാർഡിനെ അർപ്പണബോധത്തോടെ സേവിക്കുന്നത് തുടരും. ഞങ്ങളെ പരിഗണിച്ചതിന് നന്ദി.'
              )}
            </p>
          </div>

          <Button
            onClick={() => navigate('/')}
            size="lg"
            className="mt-8 animate-fade-in"
            style={{ animationDelay: '0.8s' }}
          >
            {t('Return to Homepage', 'ഹോംപേജിലേക്ക് മടങ്ങുക')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VoteOther;
