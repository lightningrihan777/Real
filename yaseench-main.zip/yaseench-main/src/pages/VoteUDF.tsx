import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { ArrowLeft, Lightbulb, Droplets, Trees, GraduationCap } from 'lucide-react';
import { useEffect, useState } from 'react';

const Confetti = ({ delay }: { delay: number }) => {
  const colors = ['bg-primary', 'bg-secondary', 'bg-success', 'bg-accent'];
  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  const randomLeft = Math.random() * 100;
  const randomDuration = 2 + Math.random() * 2;

  return (
    <div
      className={`absolute w-3 h-3 ${randomColor} rounded-full animate-confetti-fall`}
      style={{
        left: `${randomLeft}%`,
        animationDelay: `${delay}s`,
        animationDuration: `${randomDuration}s`,
      }}
    />
  );
};

const VoteUDF = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    setTimeout(() => setShowContent(true), 300);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-success/20 via-background to-secondary/20 relative overflow-hidden">
      {/* Confetti */}
      {Array.from({ length: 50 }).map((_, i) => (
        <Confetti key={i} delay={i * 0.1} />
      ))}

      <div className="container mx-auto px-4 py-12 relative z-10">
        <Button
          onClick={() => navigate('/')}
          variant="outline"
          size="lg"
          className="mb-8 animate-fade-in"
        >
          <ArrowLeft className="mr-2 h-5 w-5" />
          {t('Back to Home', 'ഹോമിലേക്ക് മടങ്ങുക')}
        </Button>

        <div className={`text-center max-w-4xl mx-auto transition-all duration-1000 ${showContent ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-success to-secondary bg-clip-text text-transparent mb-6 animate-fade-in">
            {t('Thank You! 🎉', 'നന്ദി! 🎉')}
          </h1>

          <p className="text-2xl md:text-3xl text-foreground mb-12 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            {t(
              'Thank you for choosing UDF! We promise development, progress, and transparency.',
              'UDF തിരഞ്ഞെടുത്തതിന് നന്ദി! വികസനം, പുരോഗതി, സുതാര്യത എന്നിവ ഞങ്ങൾ വാഗ്ദാനം ചെയ്യുന്നു.'
            )}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <div className="bg-card p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <Lightbulb className="h-12 w-12 text-secondary mx-auto mb-4" />
              <h3 className="font-bold text-xl mb-2 text-card-foreground">
                {t('Better Infrastructure', 'മെച്ചപ്പെട്ട അടിസ്ഥാന സൗകര്യങ്ങൾ')}
              </h3>
              <p className="text-muted-foreground">
                {t('Street lights, roads, and connectivity', 'സ്ട്രീറ്റ് ലൈറ്റുകൾ, റോഡുകൾ, കണക്റ്റിവിറ്റി')}
              </p>
            </div>

            <div className="bg-card p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 animate-fade-in" style={{ animationDelay: '0.6s' }}>
              <Droplets className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="font-bold text-xl mb-2 text-card-foreground">
                {t('Clean Water Supply', 'ശുദ്ധജല വിതരണം')}
              </h3>
              <p className="text-muted-foreground">
                {t('24/7 water availability for all', 'എല്ലാവർക്കും 24/7 ജല ലഭ്യത')}
              </p>
            </div>

            <div className="bg-card p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 animate-fade-in" style={{ animationDelay: '0.8s' }}>
              <Trees className="h-12 w-12 text-success mx-auto mb-4" />
              <h3 className="font-bold text-xl mb-2 text-card-foreground">
                {t('Green Initiatives', 'ഹരിത സംരംഭങ്ങൾ')}
              </h3>
              <p className="text-muted-foreground">
                {t('Parks, trees, and clean environment', 'പാർക്കുകൾ, മരങ്ങൾ, ശുദ്ധ പരിസരം')}
              </p>
            </div>

            <div className="bg-card p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 animate-fade-in" style={{ animationDelay: '1s' }}>
              <GraduationCap className="h-12 w-12 text-accent mx-auto mb-4" />
              <h3 className="font-bold text-xl mb-2 text-card-foreground">
                {t('Education & Digital Growth', 'വിദ്യാഭ്യാസവും ഡിജിറ്റൽ വളർച്ചയും')}
              </h3>
              <p className="text-muted-foreground">
                {t('Better schools and digital literacy', 'മെച്ചപ്പെട്ട സ്കൂളുകളും ഡിജിറ്റൽ സാക്ഷരതയും')}
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-success to-primary p-8 rounded-2xl shadow-2xl animate-fade-in" style={{ animationDelay: '1.2s' }}>
            <h2 className="text-3xl font-bold text-white mb-4">
              {t('Our Promise to You', 'നിങ്ങളോടുള്ള ഞങ്ങളുടെ വാഗ്ദാനം')}
            </h2>
            <p className="text-white/90 text-lg">
              {t(
                'Together, we will build a prosperous, sustainable, and inclusive community where everyone thrives.',
                'ഒരുമിച്ച്, നമുക്ക് എല്ലാവരും അഭിവൃദ്ധി പ്രാപിക്കുന്ന സമൃദ്ധവും സുസ്ഥിരവും ഉൾക്കൊള്ളുന്നതുമായ ഒരു സമൂഹം കെട്ടിപ്പടുക്കാം.'
              )}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VoteUDF;
